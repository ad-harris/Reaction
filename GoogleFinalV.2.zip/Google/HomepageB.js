function searcher() {
    if (event.which == 13 || event.keyCode == 13) {
        //code to execute here

        window.open("resultB.html");


    }
    console.log("hello");
};
