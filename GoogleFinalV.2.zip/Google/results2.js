

$(".the_container").html($(".results_container").sort(function(){
    return Math.random()-0.5;
}));
