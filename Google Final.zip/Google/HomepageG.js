function searcher() {
    if (event.which == 13 || event.keyCode == 13) {
        //code to execute here

        window.open("resultG.html");


    }
    console.log("hello");
};
